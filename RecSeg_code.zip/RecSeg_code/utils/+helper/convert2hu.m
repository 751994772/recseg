function hu = convert2hu(coefficient)
    hu = (coefficient - 0.0192) / 0.0192 * 1000;
end